import json
from django.contrib.auth.models import User
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from .models import Event, Registration

def home(request):
    return render(request, "home.html")

def event_data(event):
    return {
        "id": event.id,
        "name": event.name,
        "description": event.description,
        "date": event.date.isoformat(),
        "location": event.location,
        "capacity": event.capacity,
        "registered_count": event.registrations.count(),
        "available_seats": max(event.capacity - event.registrations.count(), 0),
    }

def event_list(request):
    if request.method != "GET":
        return JsonResponse({"error": "GET method required"}, status=405)
    return JsonResponse({"events": [event_data(e) for e in Event.objects.all().order_by("date")]})

def event_detail(request, event_id):
    if request.method != "GET":
        return JsonResponse({"error": "GET method required"}, status=405)
    try:
        event = Event.objects.get(id=event_id)
    except Event.DoesNotExist:
        return JsonResponse({"error": "Event not found"}, status=404)
    return JsonResponse(event_data(event))

@csrf_exempt
def register_for_event(request):
    if request.method != "POST":
        return JsonResponse({"error": "POST method required"}, status=405)

    try:
        data = json.loads(request.body or "{}")
    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON"}, status=400)

    username = str(data.get("username", "")).strip()
    email = str(data.get("email", "")).strip()
    event_id = data.get("event_id")

    if not username or not email or not event_id:
        return JsonResponse(
            {"error": "username, email and event_id are required"},
            status=400
        )

    try:
        event = Event.objects.get(id=event_id)
    except Event.DoesNotExist:
        return JsonResponse({"error": "Event not found"}, status=404)

    if event.registrations.count() >= event.capacity:
        return JsonResponse({"error": "Event is full"}, status=400)

    user, created = User.objects.get_or_create(
        username=username,
        defaults={"email": email}
    )
    if not created and user.email != email:
        user.email = email
        user.save(update_fields=["email"])

    registration, created = Registration.objects.get_or_create(
        user=user,
        event=event
    )

    if not created:
        return JsonResponse({"error": "User is already registered for this event"}, status=409)

    return JsonResponse({
        "message": "Registration successful",
        "registration_id": registration.id,
        "user": username,
        "event": event.name
    }, status=201)

def registration_list(request):
    if request.method != "GET":
        return JsonResponse({"error": "GET method required"}, status=405)

    registrations = Registration.objects.select_related("user", "event").all()
    data = [{
        "id": r.id,
        "username": r.user.username,
        "email": r.user.email,
        "event": r.event.name,
        "registered_at": r.registered_at.isoformat(),
    } for r in registrations]

    return JsonResponse({"registrations": data})
