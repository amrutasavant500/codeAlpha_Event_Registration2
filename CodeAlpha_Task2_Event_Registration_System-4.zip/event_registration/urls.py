from django.contrib import admin
from django.urls import path
from events import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.home, name="home"),
    path("api/events/", views.event_list, name="event-list"),
    path("api/events/<int:event_id>/", views.event_detail, name="event-detail"),
    path("api/register/", views.register_for_event, name="register"),
    path("api/registrations/", views.registration_list, name="registration-list"),
]
